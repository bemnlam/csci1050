% Exercise 2
ans_of_a = 6 * pi * atan(12.5) + 4

ans_of_b = 5 * tan( 3*asin(13/5) )

ans_of_c = 5 * log(7)

ans_of_d = 5 * log10(7)
