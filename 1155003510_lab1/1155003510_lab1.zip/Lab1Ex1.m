% Exercise1
% get inputs
a = input('Please enter value of a: ');
b = input('Please enter value of b: ');
c = input('Please enter value of c: ');
d = input('Please enter value of d: ');
f = input('Please enter value of f: ');
% show values
a,b,c,d,f
%   disp(a),disp(b),disp(c),disp(d),disp(f)