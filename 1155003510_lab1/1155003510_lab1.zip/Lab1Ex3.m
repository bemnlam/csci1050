% Exercise 3
array = [sin(-pi/2):0.05:cos(0)]
length(array)
